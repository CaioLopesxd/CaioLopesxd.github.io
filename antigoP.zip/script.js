const emprodução = document.querySelector('.emProdução');

emprodução.addEventListener('click', function() {
  alert('Cliquei em Em produção');
});